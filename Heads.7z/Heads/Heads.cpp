﻿// Heads.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include "UserHeader.h"



int main()
{
    system("chcp 1251>nul");
    printf("Вызов функции из stdio.h\n");
    printf("%d\n", sum(3, 2));
    printf("%d\n", diff(3, 2));
    printf("%f\n", mul(3, 2));
    printf("%f\n", div(3, 2));
    
    char* str1 = "Один";
    char* str2 = "Два";
    printf("%s", concat(str1, str2));


    printf("\n\n");
}