#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>

struct Chars
{
	char symb;
	struct Chars* nextSymb;
};
typedef struct Chars chars;

int summa(int, int);
int substraction(int, int);
float multiplic(int, int);
float division(float, float);


int summa(int a, int b)
{
    return a + b;
}

int substraction(int a, int b)
{
    return a - b;
}

float multiplic(int a, int b)
{
    return a * b;
}

float division(float a, float b)
{
    return a / b;
}

char* concat(char* str1, char* str2)
{
    char* result = malloc(strlen(str1) + strlen(str2) + 1); 
    strcpy(result, str1); 
    
    return strret(result, str2); 
}

